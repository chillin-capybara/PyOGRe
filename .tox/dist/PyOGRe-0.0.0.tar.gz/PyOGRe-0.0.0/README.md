![Verified for Python 3.7](https://github.com/JaredWogan/PyOGRe/actions/workflows/python37.yml/badge.svg)
![Verified for Python 3.8](https://github.com/JaredWogan/PyOGRe/actions/workflows/python38.yml/badge.svg)
![Verified for Python 3.9](https://github.com/JaredWogan/PyOGRe/actions/workflows/python39.yml/badge.svg)
[![License: MIT](https://img.shields.io/github/license/JaredWogan/PyOGRe)](https://github.com/JaredWogan/PyOGRe/blob/master/LICENSE)
![GitHub last commit](https://img.shields.io/github/last-commit/JaredWogan/PyOGRe)
[![GitHub repo stars](https://img.shields.io/github/stars/JaredWogan/PyOGRe?style=social)](https://github.com/JaredWogan/PyOGRe)
[![Twitter @JaredWogan](https://img.shields.io/twitter/follow/JaredWogan?style=social)](https://twitter.com/JaredWogan)
[![Twitter @BarakShoshany](https://img.shields.io/twitter/follow/BarakShoshany?style=social)](https://twitter.com/BarakShoshany)
[![Open in Visual Studio Code](https://open.vscode.dev/badges/open-in-vscode.svg)](https://open.vscode.dev/JaredWogan/PyOGRe)

# PyOGRe - A Python Object-Oriented General Relativity Package
Placeholder
